int main(){
	int ret;
	printf("I am going to exec an Commend line atgs \n");
	ret = execl("/home/chandan/traning/linux/day14","./exec",);
	printf("");	
}
